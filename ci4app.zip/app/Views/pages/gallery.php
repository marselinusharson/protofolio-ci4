<?= $this->extend('layout/template.php'); ?>

<?= $this->section('content'); ?>
<section class="pt-36 pb-32 dark:bg-gradient-to-b dark:from-black dark:to-dark">
    <div class="container flex min-h-screen justify-center items-center">
        <h4 class="font-bold text-4xl dark:text-white">Coming Soon!</h4>
    </div>
</section>
<?= $this->endSection(); ?>